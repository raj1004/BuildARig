package com.springrest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.springrest.services.*;
import com.springrest.beans.CartItem;
import com.springrest.beans.EmployeeDimensions;
import com.springrest.beans.Login;
import com.springrest.beans.Product;
import com.springrest.beans.Registration;
import com.springrest.webclients.*;
@Controller
@Scope("session")
@SessionAttributes("login")
public class SpringRestController {
	@Autowired
	SpringRestServices srs;
	@RequestMapping(value="/Form",method = RequestMethod.GET )
	public ModelAndView welcomeHome() {
		 ModelAndView mav = new ModelAndView("Form1");
		mav.addObject("login",new Login());
		return mav;
	}
	
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public ModelAndView welcomeFormData( @ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("userhome");
		view.addObject("id", login.getUserID());
		System.out.println(login.getUserID());
		boolean status =srs.ismember(login.getUserID(), login.getPassword());
		if(status){
			view.addObject("status",login.getUserID());
		}
			else{
			view = new ModelAndView("Form1");
			view.addObject("pleaseRegister","Please login");
			
			}
		return view;
	}
	
	@RequestMapping(value = "/logout")
    public ModelAndView logout( SessionStatus status) {
        System.out.println("logout()");
        ModelAndView view = new ModelAndView("Form1");
        try{
       status.isComplete();
        }
        catch(Exception e){
        	System.out.println("Issue with logout "+e);
        }
        view.addObject("logoutstatus","You have been logged out!");
        return view;
    }
	
	//Registration Page
	@RequestMapping(value="/register",method = RequestMethod.GET )
	public ModelAndView register() {
		 ModelAndView mav = new ModelAndView("register");
		 mav.addObject("Register",new Registration());
		return mav;
	}
	
	//Submit Registration form
	@RequestMapping(value="/registerSubmit",method = RequestMethod.POST )
	public ModelAndView registerSubmit(@ModelAttribute("Register") Registration register) {
		 ModelAndView mav = null;
		// mav.addObject("id",register.getUserID());
		 boolean status =srs.usernamecheck(register.getUserID());
		 if(status){
			 mav=new ModelAndView("register");
			 mav.addObject("status","DUPLICATE USER");
		 }
		 else{
			 //Add data to registration table
			 status = srs.newRegistration(register);
			 if(status){
			mav= new ModelAndView("userhome");
			 mav.addObject("status",register.getUserID());
			 }
			 else{
				 mav=new ModelAndView("register");
				 mav.addObject("status","Problem with Registration. Please try again");
			 }
		 }
		 
		 System.out.println("register submit : "+register.getUserID());
		return mav;
	}
	
	
	@RequestMapping(value="/showproduct_1",method = RequestMethod.GET)
	public ModelAndView productcatalog(@ModelAttribute("login") Login login,@RequestParam("prodtype") String prodtype) {
		ModelAndView view = new ModelAndView("products");
		view.addObject("id", login.getUserID());
		System.out.println(prodtype);
		List<Product> products =srs.getProducts(prodtype);
		if(products.size()>0){
			view.addObject(login);
			view.addObject("status","great products"+products.size());
			view.addObject("products",products);
			}
			else
			view.addObject("status","no products for this search");
		return view;
	}
	
	@RequestMapping(value="/customize",method = RequestMethod.GET)
	public ModelAndView customize(@ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("customize");
		view.addObject("id", login.getUserID());
		
		return view;
	}
	
	@RequestMapping(value="/showcart",method = RequestMethod.GET)
	public ModelAndView showCart(@ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("cart");
		view.addObject("id", login.getUserID());
		System.out.println("About to get cart details:"+login.getUserID());
		List<CartItem> cartitems =srs.getCart(login.getUserID());
		Map<Integer,Product> map =new HashMap<Integer, Product>();
		List<Product> prodlist= new ArrayList<Product>();
		int total_amount =0;
		if(cartitems.size()>0){
			for(CartItem cart:cartitems){
				total_amount= total_amount+cart.getCart_item_price();
				map.put(cart.getProduct_id(),srs.getProductByProductId(cart.getProduct_id()));
			}
			view.addObject("totalamount",total_amount);
			view.addObject("productmap",map);
			view.addObject("status","great products"+cartitems.size());
			view.addObject("cartitems",cartitems);
			}
			else
			view.addObject("status","no items in cart");
		return view;
	}
	@RequestMapping(value="/addTocart",method = RequestMethod.POST)
	public ModelAndView addtocart(@ModelAttribute("login") Login login,@RequestParam("product_id") String productId,@RequestParam("carlist") String quantity) {
		ModelAndView view = new ModelAndView("userhome");
		System.out.println(productId+"^^^^^^^^^^^^^^^^^^^"+quantity);
		view.addObject("id", login.getUserID());
		System.out.println(login.getUserID());
		boolean status =srs.addCart(Integer.parseInt(productId), Integer.parseInt(quantity), login.getUserID());
		if(status){
			view.addObject("status",login.getUserID()+" Cart Updated");
			view.addObject(login);
			}
			else
			view.addObject("status","no items in cart");
		return view;
	}
	
	@RequestMapping(value="/deleteFromCart",method = RequestMethod.GET)
	public ModelAndView deleteFromCart(@ModelAttribute("login") Login login,@RequestParam("cartid") String cartid,@RequestParam("product_id") String product_id,
			@RequestParam("userID") String userID,
			@RequestParam("product_quantity") String product_quantity,
			@RequestParam("cart_item_price") String cart_item_price) {
		ModelAndView view = new ModelAndView("userhome");
		CartItem cart=new CartItem();
		cart.setCart_item_id(Integer.parseInt(cartid));
		cart.setProduct_id(Integer.parseInt(product_id));
		cart.setUserID(userID);
		cart.setProduct_quantity(Integer.parseInt(product_quantity));
		cart.setCart_item_price(Integer.parseInt(cart_item_price));
		srs.deleteFromCart(cart);
		
		System.out.println("Delete controller"+cartid);
		view.addObject("id", login.getUserID());
		
		return view;
	}
	
	@RequestMapping(value="/checkout",method = RequestMethod.GET)
	public ModelAndView checkout(@ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("checkout");
		view.addObject("id", login.getUserID());
		
		String address= srs.getAddress(login.getUserID());
		
		view.addObject("address",address);
		
		return view;
	}
	
	@RequestMapping(value="/orderPlaced",method = RequestMethod.GET)
	public ModelAndView orderPlaced(@ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("orderPlaced");
		view.addObject("id", login.getUserID());
		System.out.println("ID after order placement "+login.getUserID());
		
		return view;
	}
	
	@RequestMapping(value="/continueShopping",method = RequestMethod.GET)
	public ModelAndView continueShopping(@ModelAttribute("login") Login login) {
		ModelAndView view = new ModelAndView("userhome");
		view.addObject("id", login.getUserID());
		System.out.println("Redirecting to homepage "+login.getUserID());
		
		return view;
	}
}
