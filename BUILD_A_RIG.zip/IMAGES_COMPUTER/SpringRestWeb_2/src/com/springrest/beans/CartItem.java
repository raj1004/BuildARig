package com.springrest.beans;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
   @Entity
   @Table(name = "CartItem")
public class CartItem {
	   @Id
	   @Column(name = "f_cart_item_id")
	   
	   private int cart_item_id;

	  /* @ManyToOne
	   @JoinColumn(name = "f_product_id")
	    private Product product;
	   */
	   @Column(name = "f_product_id")
	   private int product_id;
	   
	  /* @ManyToOne
	   @JoinColumn(name = "f_cart_id")
	   private SHOPPING_CART_USER cart;
	   */
	  /* @Column(name = "f_cart_id")
	   private int cart_id;
*/
	   
	   
	   @Column(name = "f_user_id")
	   private String userID;
	   
	   @Column(name = "f_product_quantity")
	   private int product_quantity;
	 
	   
	   @Column(name = "f_cart_item_price")
	   private int cart_item_price;
	    public CartItem() {}
	    
	    
	    
		@Override
		public String toString() {
			return "CartItem [cart_item_id=" + cart_item_id + ", product="
					+ product_id + ", userid=" + userID + ", product_quantity="
					+ product_quantity + ", cart_item_price=" + cart_item_price
					+ "]";
		}

		public int getProduct_id() {
			return product_id;
		}



		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}



		public int getCart_item_id() {
			return cart_item_id;
		}
		public void setCart_item_id(int cart_item_id) {
			this.cart_item_id = cart_item_id;
		}
	/*	public Product getProduct() {
			return product;
		}
		public void setProduct(Product product) {
			this.product = product;
		}*/
		
		
		
		
		/*public SHOPPING_CART_USER getCart() {
			return cart;
		}
		public void setCart(SHOPPING_CART_USER cart) {
			this.cart = cart;
		}*/
	
	
		public int getProduct_quantity() {
			return product_quantity;
		}

		public String getUserID() {
			return userID;
		}



		public void setUserID(String userID) {
			this.userID = userID;
		}



		public void setProduct_quantity(int product_quantity) {
			this.product_quantity = product_quantity;
		}



		/*	public int getCart_item_price() {
			return getProduct().getProduct_price()*Integer.parseInt(getProduct_quantity());
		}*/
		
		
		public void setCart_item_price(int cart_item_price) {
			this.cart_item_price = cart_item_price;
		}



		public int getCart_item_price() {
			return cart_item_price;
		}
	     
	    // getters and setters

}
