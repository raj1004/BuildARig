package com.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Registration")
public class Registration {

	@Id
	@Column(name = "f_user_id")
	private String userID;
	@Column(name = "f_password")
	private String password;
	@Column(name = "f_fname")
	private String fname;
	@Column(name = "f_lname")
	private String lname;
	@Column(name = "f_age")
	private int age;
	@Column(name = "f_address")
	private String address;
	@Column(name = "f_city")
	private String city;
	
	@Column(name = "f_phone")
	private String phone;
	
	@Column(name = "f_gender")
	private String gender;
	@Column(name = "f_state")
	private String state;
	@Column(name = "f_pin")
	private int pin;

	@Override
	public String toString() {
		return "Registration [userID=" + userID + ", fname=" + fname
				+ ", lname=" + lname + ", age=" + age + ", address=" + address
				+ ", city=" + city + ", phone=" + phone + ", gender=" + gender
				+ ", state=" + state + ", pin=" + pin + "]";
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

}
