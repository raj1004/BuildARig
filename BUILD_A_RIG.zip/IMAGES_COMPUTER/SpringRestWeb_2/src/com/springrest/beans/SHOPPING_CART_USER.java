package com.springrest.beans;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
   @Entity
   @Table(name = "SHOPPING_CART_USER")
public class SHOPPING_CART_USER {
	   
	   @Id
	   @Column(name = "f_cart_id")
	   @GeneratedValue(strategy=GenerationType.AUTO)
	   private int cart_id;

	  /* @OneToMany(cascade = CascadeType.ALL, mappedBy="cart")
	   private Set<CartItem> cartItems;*/
	   
	   @Column(name = "f_cart_price")
	  private int cartprice;
	   
	   @Column(name = "f_user_id")
		private String userID;

	   @Column(name = "f_cart_item_id")
	   private int cart_item_id;
	 //  private Login login;
	   
	   
	   
	   public int getCart_id() {
		return cart_id;
	}

	public int getCart_item_id() {
		return cart_item_id;
	}

	public void setCart_item_id(int cart_item_id) {
		this.cart_item_id = cart_item_id;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}

	/*public Set<CartItem> getCartItems() {
		return cartItems;
	}

	public void setCartItems(Set<CartItem> cartItems) {
		this.cartItems = cartItems;
	}*/

	public int getCartprice() {
		return cartprice;
	}

	public void setCartprice(int cartprice) {
		this.cartprice = cartprice;
	}
	/*@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "f_user_id")
	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
*/
	
	    public SHOPPING_CART_USER() {
	    	
	    }
	     
	    // getters and setters

}
