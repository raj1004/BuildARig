package com.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
   @Entity
   @Table(name = "Product")
public class Product {
	   
	   @Id
	   @Column(name = "f_product_id")
	   private int product_id;

	   @Column(name = "f_product_name")
	   private String product_name;

	   @Column(name = "f_product_type")
	   private String product_type;
	   
	   @Column(name = "f_product_price")
	   private int product_price;


	   @Column(name = "f_product_supplier")
	   private String product_supplier;
	   
	   @Column(name = "f_product_size")
	   private String product_size;
	   
	   @Column(name = "f_product_description")
	   private String product_description;
	  
	    public Product() {}
	    
	    

	    
		public Product(int product_id, String product_name,
				String product_type, int product_price,
				String product_supplier, String product_size,
				String product_description) {
			super();
			this.product_id = product_id;
			this.product_name = product_name;
			this.product_type = product_type;
			this.product_price = product_price;
			this.product_supplier = product_supplier;
			this.product_size = product_size;
			this.product_description = product_description;
		}
		public int getProduct_id() {
			return product_id;
		}

		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}

		public String getProduct_name() {
			return product_name;
		}

		public void setProduct_name(String product_name) {
			this.product_name = product_name;
		}

		public String getProduct_type() {
			return product_type;
		}

		public void setProduct_type(String product_type) {
			this.product_type = product_type;
		}

		public int getProduct_price() {
			return product_price;
		}

		public void setProduct_price(int product_price) {
			this.product_price = product_price;
		}

		public String getProduct_supplier() {
			return product_supplier;
		}

		public void setProduct_supplier(String product_supplier) {
			this.product_supplier = product_supplier;
		}

		public String getProduct_size() {
			return product_size;
		}

		public void setProduct_size(String product_size) {
			this.product_size = product_size;
		}

		public String getProduct_description() {
			return product_description;
		}

		public void setProduct_description(String product_description) {
			this.product_description = product_description;
		}
	     
	    // getters and setters
	    
	    
	   

	

	
}
