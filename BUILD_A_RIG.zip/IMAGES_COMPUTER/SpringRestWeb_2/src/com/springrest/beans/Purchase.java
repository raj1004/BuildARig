package com.springrest.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
   @Entity
   @Table(name = "Purchase")
public class Purchase {
	   @Id
	   @Column(name = "f_purchase_id")
	   @GeneratedValue(strategy=GenerationType.AUTO)
	   private int purchase_id;

	   @Column(name = "f_cust_id")
	   private String cust_id;

	   @Column(name = "f_purchase_date")
	   private String purchased_date;
	   
	   private Login login;

	public Purchase() {
		
	}

	public int getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(int purchase_id) {
		this.purchase_id = purchase_id;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public String getPurchased_date() {
		return purchased_date;
	}

	public void setPurchased_date(String purchased_date) {
		this.purchased_date = purchased_date;
	}
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "f_user_id")
	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
	   
	
	  
	   

	

	
}
