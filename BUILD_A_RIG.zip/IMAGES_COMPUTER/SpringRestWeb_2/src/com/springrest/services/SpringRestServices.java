package com.springrest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.springrest.beans.CartItem;
import com.springrest.beans.EmployeeDimensions;
import com.springrest.beans.Login;
import com.springrest.beans.Product;
import com.springrest.beans.Registration;
import com.springrest.beans.SHOPPING_CART_USER;
import com.springrest.dao.SpringRestUpdates;

@Component
public class SpringRestServices {
@Autowired
SpringRestUpdates spreupd;
public boolean ismember(String username,String password){
	Login member =spreupd.getMember(username, password);
	boolean status =null!=member?true:false;
	
	System.out.println("Login check: "+status);
	return status;
}



public List<Product> getProducts(String prodtype) {
	List <Product> products =spreupd.getProducts(prodtype);
	return products;
}

public List<CartItem> getCart(String username) {
	List<CartItem> cart =spreupd.getCart(username);
	List<Integer> cart_item_list =new ArrayList<Integer>();
	for(CartItem cart_item_id:cart) {
		cart_item_list.add(cart_item_id.getCart_item_id());
	}
	Integer cart_id_list [] =cart_item_list.toArray(new Integer[cart_item_list.size()]);
	List<CartItem>cart_items_list =spreupd.getCartItems(cart_id_list);
	return cart_items_list;
}

/*public List<CartItem> getCart(String username)
{
	List <CartItem> cart =this.spreupd.getCart(username);
	return cart;
}*/

/*public List<CartItem> getCart(String username)
{
  List<CartItem> cart =this.spreupd.getCart(username);
  for(int i=0;i<cart.size();i++) {
	  for(int j=1;j<cart.size();j++) {
	if(cart.get(i).getProduct_id()==cart.get(j).getProduct_id())  {
		
	if(cart.get(i).getProduct_quantity()>cart.get(j).getProduct_quantity()) {
		
		cart.remove(j);
	}else if(cart.get(i).getProduct_quantity()<cart.get(j).getProduct_quantity()) {
		
		cart.remove(i);
	}
	}
	  }
  }
  
  return cart;
}*/

public boolean addCart(int productId, int quantity, String userID)
{
  boolean status = true;
  System.out.println("Adding to cart service "+productId+""+quantity+""+userID);
  Product product = spreupd.getProductbyproductId(productId);
  System.out.println("Adding to cart service "+productId+""+quantity+""+userID+"&&&&&&&&&&&&&&&"+product.getProduct_price());
  try
  {
	  Random rand=new Random();
	  int value=rand.nextInt(500);
    CartItem cartItem = spreupd.isIteminCartItem(productId, userID);
    if (cartItem != null)
    {System.out.println("timesofindai");
    CartItem cart_item = new CartItem();
    cart_item.setCart_item_id(value);
    cart_item.setProduct_id(productId);
    cart_item.setUserID(userID);
    
    cart_item.setCart_item_price(cartItem.getCart_item_price() + product.getProduct_price() * quantity);
    cart_item.setProduct_quantity(cartItem.getProduct_quantity() + quantity);
    spreupd.addtocartitem(cart_item);
    
    }
    else
    {System.out.println("timesofindaidsfdfdfdf");
      CartItem cart_item = new CartItem();
      cart_item.setProduct_id(productId);
      cart_item.setProduct_quantity(quantity);
      cart_item.setUserID(userID);
      cart_item.setCart_item_price(product.getProduct_price() * quantity);
      System.out.println("**********************"+cart_item.getCart_item_price());
      spreupd.addtocartitem(cart_item);
    }
  }
  catch (Exception e)
  {System.out.println("sdfdsfdsffdsfds"+e);
    status = false;
  }
  return status;
}
public boolean usernamecheck(String userID) {
	Login member =spreupd.getUsername(userID);
	boolean status =null!=member?true:false;
	return status;
}



public boolean newRegistration(Registration register) {
	// TODO Auto-generated method stub
	Login member = new Login();
	member.setUserID(register.getUserID());
	member.setPassword(register.getPassword());
	spreupd.newLogin(member);
	boolean status = spreupd.newRegistration(register);
	return status;
}



public Product getProductByProductId(int product_id) {
	Product product =spreupd.getProductbyproductId(product_id);
	return product;
	// TODO Auto-generated method stub
	
}



public void deleteFromCart(CartItem cart) {
	// TODO Auto-generated method stub
	spreupd.deleteFromCart(cart);
}



public String getAddress(String userID) {
	// TODO Auto-generated method stub
	String address=spreupd.getAddress(userID);
	return address;
}

}
