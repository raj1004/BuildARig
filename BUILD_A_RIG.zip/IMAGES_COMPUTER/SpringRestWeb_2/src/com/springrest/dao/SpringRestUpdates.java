package com.springrest.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.omg.CORBA.ShortHolder;
import org.springframework.stereotype.Component;

import com.springrest.beans.CartItem;
import com.springrest.beans.EmployeeDimensions;
import com.springrest.beans.Login;
import com.springrest.beans.Product;
import com.springrest.beans.Registration;
import com.springrest.beans.SHOPPING_CART_USER;


@Component
public class SpringRestUpdates {

	/*public boolean updateempdata(EmployeeDimensions employee){
		boolean status =false;
		SessionFactory factory; 

	    try{
	    	  Configuration configuration= new AnnotationConfiguration().configure();
		  	  configuration.getProperty("hibernate.dialect");
		  	  System.out.println("findshine"+configuration.getProperty("hibernate.dialect"));
		  	 factory= configuration.buildSessionFactory();
	    }catch (Throwable ex) { 
	       System.err.println("Failed to create sessionFactory object." + ex);
	       throw new ExceptionInInitializerError(ex); 
	    }			
	      Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         session.saveOrUpdate(employee); 
	         tx.commit();
	         
	         status =true;
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	    return status;
		
	}*/
	
	public SessionFactory getSessionFactory(){
		SessionFactory factory = null;
		try {
			Configuration configuration = new AnnotationConfiguration()
					.configure();
			configuration.getProperty("hibernate.dialect");
			System.out.println("findshine"
					+ configuration.getProperty("hibernate.dialect"));
			factory = configuration.buildSessionFactory();
		} catch (Exception e) {
			System.out.println("error in implementation");
		}
		return factory;
	}

	public Login getMember(String username,String password) {

		SessionFactory factory = getSessionFactory();
		Login member = null;

		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(Login.class);
			criteria.add(Restrictions.eq("userID", username));
			criteria.add(Restrictions.eq("password", password));
			member = (Login) criteria.uniqueResult();

		}
		return member;
	}
	
	public List<Product> getProducts(String prodtype) {
		SessionFactory factory = getSessionFactory();
		List <Product>products= null;
		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(Product.class);
		criteria.add(Restrictions.eq("product_type", prodtype.toUpperCase()));
			products =(List <Product>)criteria.list();
		}
		//factory.close();
		return products;
	}
	/*public List<SHOPPING_CART_USER> getCart(String username) {
		SessionFactory factory = getSessionFactory();
		List <SHOPPING_CART_USER>shopcart= null;
		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(SHOPPING_CART_USER.class);
		criteria.add(Restrictions.eq("userID", username));
		shopcart =(List<SHOPPING_CART_USER>)criteria.list();
		System.out.println("-------------------------->"+shopcart.size());
		}
		//factory.close();
		return shopcart;
	}*/
	public List<CartItem> getCart(String username) {
		SessionFactory factory = getSessionFactory();
		List<CartItem> shopcart = null;
		if (factory != null)
	    {
	      Criteria criteria = factory.openSession()
	        .createCriteria(CartItem.class);
	      criteria.add(Restrictions.eq("userID", username));
	      shopcart = criteria.list();
	      System.out.println("-------------------------->" + shopcart.size());
	    }
	    return shopcart;
	}
	public List<CartItem> getCartItems(Integer[] cart_id_list) {
		SessionFactory factory = getSessionFactory();
		List <CartItem>shopcart= null;
		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(CartItem.class);
		criteria.add(Restrictions.in("cart_item_id", cart_id_list ));
		shopcart =(List<CartItem>)criteria.list();
		}
		//factory.close();
		return shopcart;
	}
	
	public Product getProductbyproductId(int prodId) {
		SessionFactory factory = getSessionFactory();
		Product product= null;

		if (null != factory) {
			System.out.println("Prod ID in DAO "+prodId);
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(Product.class);
		criteria.add(Restrictions.eq("product_id", prodId));
		product = (Product) criteria.uniqueResult();
		}
		//factory.close();
		return product;
}
	
	public boolean addtocartitem(CartItem cartItem){
		boolean status =false;
		SessionFactory factory = getSessionFactory(); 
	      Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         System.out.println("sdfsdfsdfdsfdsfdsfdsfdsfdsfds"+cartItem.getUserID());
	         session.saveOrUpdate(cartItem); 
	         tx.commit();
	         
	         status =true;
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	    return status;
		
	}
	
	public CartItem isIteminCartItem(int productId,String userid) {
		SessionFactory factory = getSessionFactory();
	CartItem shopcaritem= null;

		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(CartItem.class);
		criteria.add(Restrictions.eq("product_id", productId ));
		criteria.add(Restrictions.eq("userID", userid ));
		shopcaritem = (CartItem) criteria.uniqueResult();
		System.out.println("###################3dao check carrt"+shopcaritem);
		}
		//factory.close();
		return shopcaritem;
	}

	public Login getUsername(String userID) {
		SessionFactory factory = getSessionFactory();
		Login member = null;

		if (null != factory) {
			Criteria criteria = (Criteria) factory.openSession()
					.createCriteria(Login.class);
			criteria.add(Restrictions.eq("userID", userID));
			member = (Login) criteria.uniqueResult();
		}
		return member;
	
	}
	
	

	public boolean newRegistration(Registration register) {
		// TODO Auto-generated method stub
		boolean status =false;
		SessionFactory factory = getSessionFactory(); 

	      Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         session.saveOrUpdate(register); 
	         tx.commit();
	         
	         status =true;
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	    return status;
	}

	public void newLogin(Login member) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		boolean status = false;
		SessionFactory factory = getSessionFactory(); 

	      Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         session.saveOrUpdate(member); 
	         tx.commit();
	         
	         status =true;
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	      if(status)
	    	  System.out.println("Added to login for "+member.getUserID());
	      else{
	    	  System.out.println("Error adding new login");
	      }
	
	}

	public void deleteFromCart(CartItem cart) {
		// TODO Auto-generated method stub
		SessionFactory factory = getSessionFactory();
		Boolean status = false;
		Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         session.delete(cart); 
	         tx.commit();
	         
	         status =true;
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	}

	public String getAddress(String userID) {
		SessionFactory factory = getSessionFactory();
		Registration register = null;
	if (null != factory) {
		Criteria criteria = (Criteria) factory.openSession()
				.createCriteria(Registration.class);
		criteria.add(Restrictions.eq("userID", userID));
		register = (Registration) criteria.uniqueResult();
	}
	System.out.println("Address from Registraion for "+register.getUserID()+"is "+register.getAddress());
	return register.getAddress();
	}
	
	
}
